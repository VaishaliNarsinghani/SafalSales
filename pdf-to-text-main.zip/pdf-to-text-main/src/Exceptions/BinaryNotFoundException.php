<?php

namespace Spatie\PdfToText\Exceptions;

use Exception;

class BinaryNotFoundException extends Exception
{
}
